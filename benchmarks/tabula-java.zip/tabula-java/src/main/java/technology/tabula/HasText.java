package technology.tabula;

public interface HasText {

	String getText();
	String getText(boolean useLineReturns);

}
