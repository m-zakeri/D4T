package simulator.ontology;

import jade.content.Concept;

/** file: SavingPath.java
 * @author ontology bean generator
 * @version 2003/10/26
 */


public class SavingPath implements Concept{ 

  // String directory
  private String directory;
  public void setDirectory(String s) { this.directory=s; }
  public String getDirectory() { return this.directory; }

}
