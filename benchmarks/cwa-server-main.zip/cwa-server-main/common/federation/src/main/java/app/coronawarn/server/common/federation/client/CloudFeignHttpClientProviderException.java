package app.coronawarn.server.common.federation.client;

public class CloudFeignHttpClientProviderException extends RuntimeException {

  public CloudFeignHttpClientProviderException(final Throwable cause) {
    super(cause);
  }
}
