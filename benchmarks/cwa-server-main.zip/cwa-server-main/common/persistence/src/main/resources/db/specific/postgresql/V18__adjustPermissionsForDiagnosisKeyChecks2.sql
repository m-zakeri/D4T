GRANT SELECT ON TABLE diagnosis_key TO "cwa_federation_download";
