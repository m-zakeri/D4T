GRANT SELECT, DELETE ON TABLE diagnosis_key TO "cwa_distribution";
GRANT INSERT ON TABLE diagnosis_key TO "cwa_submission";

