ALTER TABLE check_in_protected_reports ADD COLUMN mac BYTEA;
