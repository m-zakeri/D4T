GRANT SELECT, DELETE ON TABLE trace_time_interval_warning TO "cwa_distribution";
