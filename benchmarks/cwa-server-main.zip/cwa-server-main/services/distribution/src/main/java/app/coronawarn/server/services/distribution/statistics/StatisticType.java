package app.coronawarn.server.services.distribution.statistics;

public enum StatisticType {
  STANDARD,
  LOCAL
}
