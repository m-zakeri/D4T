package app.coronawarn.server.services.distribution.dgc.exception;

public class DscListDecodeException extends Exception {

  public DscListDecodeException(String message, Throwable cause) {
    super(message, cause);
  }
}
