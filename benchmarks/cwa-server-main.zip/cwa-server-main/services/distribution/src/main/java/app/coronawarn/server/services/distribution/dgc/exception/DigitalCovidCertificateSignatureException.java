package app.coronawarn.server.services.distribution.dgc.exception;

public class DigitalCovidCertificateSignatureException extends RuntimeException {

  public DigitalCovidCertificateSignatureException(String message, Throwable cause) {
    super(message, cause);
  }

}
