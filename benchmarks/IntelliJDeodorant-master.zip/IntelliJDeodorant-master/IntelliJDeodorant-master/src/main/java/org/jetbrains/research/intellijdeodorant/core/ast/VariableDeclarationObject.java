package org.jetbrains.research.intellijdeodorant.core.ast;

import com.intellij.psi.PsiVariable;

public abstract class VariableDeclarationObject {

    public abstract PsiVariable getVariableDeclaration();

    public abstract String getName();
}
