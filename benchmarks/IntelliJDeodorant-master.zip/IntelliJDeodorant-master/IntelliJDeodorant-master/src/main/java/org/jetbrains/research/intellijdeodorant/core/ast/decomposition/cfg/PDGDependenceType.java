package org.jetbrains.research.intellijdeodorant.core.ast.decomposition.cfg;

public enum PDGDependenceType {
    CONTROL,
    DATA,
    ANTI,
    OUTPUT
}
