package org.jetbrains.research.intellijdeodorant.core.ast;

public enum LiteralType {
	
    BOOLEAN,
    CHARACTER,
    NULL,
    NUMBER,
    STRING,
    TYPE

}
