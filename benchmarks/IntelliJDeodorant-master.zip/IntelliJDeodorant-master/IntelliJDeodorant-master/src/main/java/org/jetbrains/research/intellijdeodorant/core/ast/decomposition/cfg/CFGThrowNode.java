package org.jetbrains.research.intellijdeodorant.core.ast.decomposition.cfg;

import org.jetbrains.research.intellijdeodorant.core.ast.decomposition.AbstractStatement;

class CFGThrowNode extends CFGNode {

    CFGThrowNode(AbstractStatement statement) {
        super(statement);
    }

}
