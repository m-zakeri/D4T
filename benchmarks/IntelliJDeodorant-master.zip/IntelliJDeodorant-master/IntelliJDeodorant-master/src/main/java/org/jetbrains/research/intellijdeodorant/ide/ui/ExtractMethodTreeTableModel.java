package org.jetbrains.research.intellijdeodorant.ide.ui;

import com.intellij.psi.PsiVariable;
import com.intellij.ui.treeStructure.treetable.TreeTableModel;
import org.jetbrains.research.intellijdeodorant.IntelliJDeodorantBundle;
import org.jetbrains.research.intellijdeodorant.core.ast.decomposition.cfg.ASTSlice;
import org.jetbrains.research.intellijdeodorant.ide.refactoring.extractMethod.ExtractMethodCandidateGroup;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.util.ArrayList;
import java.util.List;

public class ExtractMethodTreeTableModel extends DefaultTreeModel implements TreeTableModel {
    protected List<ExtractMethodCandidateGroup> candidateRefactoringGroups = new ArrayList<>();
    private final String[] columnNames = new String[]{
            IntelliJDeodorantBundle.message("long.method.panel.source.method"),
            IntelliJDeodorantBundle.message("long.method.panel.variable.name")
    };

    public ExtractMethodTreeTableModel() {
        super(new DefaultMutableTreeNode(null));
    }

    public void setCandidateRefactoringGroups(List<ExtractMethodCandidateGroup> candidateRefactoringGroups) {
        this.candidateRefactoringGroups = candidateRefactoringGroups;
        reload();
    }

    public List<ExtractMethodCandidateGroup> getCandidateRefactoringGroups() {
        return candidateRefactoringGroups;
    }

    @Override
    public boolean isLeaf(Object node) {
        return node instanceof ASTSlice;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Class getColumnClass(int column) {
        if (column == 0) {
            return TreeTableModel.class;
        } else if (column == 1) {
            return ExtractMethodCandidateGroup.class;
        }
        return String.class;
    }

    @Override
    public Object getValueAt(Object o, int index) {
        if (o instanceof ASTSlice) {
            ASTSlice entry = (ASTSlice) o;
            PsiVariable variable = entry.getLocalVariableCriterion();
            if (index == 1) {
                return variable == null ? "" : variable.getName();
            }
            return "";
        } else if (o instanceof ExtractMethodCandidateGroup) {
            ExtractMethodCandidateGroup group = (ExtractMethodCandidateGroup) o;
            switch (index) {
                case 0:
                    return group.toString();
                case 1:
                    PsiVariable firstCandidate = group.getCandidates().iterator().next().getLocalVariableCriterion();
                    return firstCandidate == null ? "" : firstCandidate.getName();
                default:
                    return "";
            }
        }
        return "";
    }

    @Override
    public int getChildCount(Object parent) {
        if (parent instanceof ExtractMethodCandidateGroup) {
            ExtractMethodCandidateGroup group = (ExtractMethodCandidateGroup) parent;
            return group.getCandidates().size();
        } else if (parent instanceof ASTSlice) {
            return 0;
        } else {
            return candidateRefactoringGroups.size();
        }
    }

    @Override
    public Object getChild(Object parent, int index) {
        if (parent instanceof ExtractMethodCandidateGroup) {
            ExtractMethodCandidateGroup group = (ExtractMethodCandidateGroup) parent;
            ArrayList<ASTSlice> slices = group.getCandidates();
            return slices.get(index);
        } else {
            return candidateRefactoringGroups.get(index);
        }
    }

    @Override
    public boolean isCellEditable(Object node, int column) {
        return false;
    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        if (parent instanceof ExtractMethodCandidateGroup && child instanceof ASTSlice) {
            ExtractMethodCandidateGroup group = (ExtractMethodCandidateGroup) parent;
            ArrayList<ASTSlice> slices = group.getCandidates();
            return slices.indexOf(child);
        }
        return -1;
    }

    @Override
    public void setValueAt(Object aValue, Object node, int column) {
    }

    @Override
    public void setTree(JTree tree) {
    }

}
