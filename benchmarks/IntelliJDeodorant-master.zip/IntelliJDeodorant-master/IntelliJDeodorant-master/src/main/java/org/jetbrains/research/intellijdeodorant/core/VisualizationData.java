package org.jetbrains.research.intellijdeodorant.core;

interface VisualizationData {
    int getDistinctSourceDependencies();

    int getDistinctTargetDependencies();
}
