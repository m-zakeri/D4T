/**
 * @see Main.StateEnum#A **/
public class A extends State {
    public void main() {
        System.out.println("A");
    }
}