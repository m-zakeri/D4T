package ru.tests;

public abstract class State {
    public abstract int getState();

    public abstract void main2();

    public abstract void main1();
}