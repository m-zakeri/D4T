/**
 * @see Main#D **/
public class D extends State {
    public int getState() {
        return Main.D;
    }

    public void main() {
        System.out.println("C");
    }
}