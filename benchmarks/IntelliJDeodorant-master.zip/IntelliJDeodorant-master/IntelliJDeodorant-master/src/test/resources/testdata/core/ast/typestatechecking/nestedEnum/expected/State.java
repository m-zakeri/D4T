public abstract class State {
    public abstract void main();
}