public class B extends Base {
    public void main() {
        System.out.println("other");
    }
}
