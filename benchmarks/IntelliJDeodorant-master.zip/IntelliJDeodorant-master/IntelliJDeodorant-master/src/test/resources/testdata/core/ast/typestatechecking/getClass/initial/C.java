public class C extends Base {
}
