public abstract class State {
    public abstract int getState();

    public abstract int main(int a);
}