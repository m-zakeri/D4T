public class A extends Base {
}
