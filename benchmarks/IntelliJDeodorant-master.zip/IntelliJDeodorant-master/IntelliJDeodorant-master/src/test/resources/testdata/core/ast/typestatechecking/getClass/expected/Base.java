public abstract class Base {
    public abstract void main();
}
