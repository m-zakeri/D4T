public abstract class State {
    public abstract int getState();

    public abstract void main();

    public abstract void main2();
}