public abstract class State {
    public abstract int getState();

    public abstract void main();
}