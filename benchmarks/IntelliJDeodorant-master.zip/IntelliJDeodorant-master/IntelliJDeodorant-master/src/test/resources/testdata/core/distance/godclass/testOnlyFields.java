package ru.hse.godclass;

public class Simple {
    public int totoa = 10;
    public int totob = 10;
    public int totoc = 10;
    public int totod = 10;
    public int totoe = 10;
    public int totof = 10;
    public int totog = 10;
    public int totoh = 10;
    public int totok = 10;
    public int atoto = 10;
    public int btoto = 10;
    public int ctoto = 10;
    public int dtoto = 10;
    public int etoto = 10;
    public int ftoto = 10;
    public int gtoto = 10;
    public int htoto = 10;
    public int toqto = 10;
    public int towto = 10;
    public int toeto = 10;
    public int torto = 10;
    public int totto = 10;
    public int toyto = 10;
    public int toyto = 10;
    public int touto = 10;
    public int toito = 10;
    public int tooto = 10;
    public int topto = 10;
}