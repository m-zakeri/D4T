public class A extends Base {
    public void main() {
        System.out.println("A");
    }
}
