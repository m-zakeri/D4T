/**
 * @see Main#A **/
public class A extends State {
    public int getState() {
        return Main.A;
    }

    public void main() {
        System.out.println("A");
        System.out.println("Other");
    }
}