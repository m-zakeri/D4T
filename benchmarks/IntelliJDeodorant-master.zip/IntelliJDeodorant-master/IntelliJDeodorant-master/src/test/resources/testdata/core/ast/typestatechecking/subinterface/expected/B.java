interface B extends State {
}
