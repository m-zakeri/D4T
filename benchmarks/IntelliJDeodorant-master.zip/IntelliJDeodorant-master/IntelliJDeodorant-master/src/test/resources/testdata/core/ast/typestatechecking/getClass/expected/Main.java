public class Main {
    Base state;

    void main() {
        state.main();
    }
}