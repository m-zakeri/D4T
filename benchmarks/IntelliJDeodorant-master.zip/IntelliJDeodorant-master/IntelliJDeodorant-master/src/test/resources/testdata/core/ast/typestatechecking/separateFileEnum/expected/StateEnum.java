public enum StateEnum {
    A, B, C
}
