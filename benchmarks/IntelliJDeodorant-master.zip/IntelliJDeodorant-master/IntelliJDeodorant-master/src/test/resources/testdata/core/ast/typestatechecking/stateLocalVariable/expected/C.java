/**
 * @see Main#C **/
public class C extends State {
    public void main() {
        System.out.println("C");
    }
}