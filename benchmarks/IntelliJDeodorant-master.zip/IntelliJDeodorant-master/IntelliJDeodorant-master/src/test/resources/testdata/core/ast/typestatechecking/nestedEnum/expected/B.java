/**
 * @see Main.StateEnum#B **/
public class B extends State {
    public void main() {
        System.out.println("B");
    }
}