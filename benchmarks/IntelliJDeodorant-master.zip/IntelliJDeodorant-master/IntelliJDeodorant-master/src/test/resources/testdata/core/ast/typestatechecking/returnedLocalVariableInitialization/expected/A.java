/**
 * @see Main#A **/
public class A extends State {
    public int getState() {
        return Main.A;
    }

    public int main(int a) {
        a = 3;
        return a;
    }
}