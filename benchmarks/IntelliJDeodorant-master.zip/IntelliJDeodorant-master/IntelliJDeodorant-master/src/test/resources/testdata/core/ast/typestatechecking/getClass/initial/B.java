public class B extends Base {
}
