import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

/**
 * @see Main#C **/
public class C extends State {
    public int getState() {
        return Main.C;
    }

    public void main() {
    }

    public void main2() {
        OutputStream output = new ByteArrayOutputStream();
    }
}