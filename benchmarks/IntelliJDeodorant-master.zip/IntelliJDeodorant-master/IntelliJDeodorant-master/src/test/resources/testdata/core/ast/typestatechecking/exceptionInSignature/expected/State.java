import java.io.IOException;

public abstract class State {
    public abstract int getState();

    public abstract void main(Main main) throws IOException;

    public abstract void main2(Main main) throws IOException;
}