#!/bin/sh
#cleanup script

rm -rf $1/utils
