exports.a = function () {
    return b;
};
var b = require('b');
