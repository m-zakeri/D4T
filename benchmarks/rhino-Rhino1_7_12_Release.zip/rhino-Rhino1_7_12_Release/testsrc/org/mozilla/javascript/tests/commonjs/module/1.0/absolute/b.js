exports.foo = function() {};
