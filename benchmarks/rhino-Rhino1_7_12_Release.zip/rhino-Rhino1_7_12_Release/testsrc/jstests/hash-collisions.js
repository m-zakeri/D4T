// We expect that a String named "collisions" is part of the global scope
JSON.parse(collisions);
