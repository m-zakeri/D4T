package biz.ganttproject.impex.msproject2;

public class WebStartIDClass {

}
