# factory-pattern-example
Factory Design Pattern Example in java
