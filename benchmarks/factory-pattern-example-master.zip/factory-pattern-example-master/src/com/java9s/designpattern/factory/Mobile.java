package com.java9s.designpattern.factory;

public interface Mobile {
	public static final String IPHONE="IPHONE";
	public static final String SONY="sony";
	public static final String SAMSUNG="samsung";
}
