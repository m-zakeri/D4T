/**
 * Internal classes used by JFreeChart (not exposed in the public API).
 */
package org.jfree.chart.internal;
