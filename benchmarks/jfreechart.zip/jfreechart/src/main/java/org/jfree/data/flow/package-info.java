/**
 * Data interfaces and classes for flow plots (a type of Sankey chart).
 */
package org.jfree.data.flow;
